# qt-chat

Happy litle chat friend to talk to ppl

install deps

```bash
npm install
```

run both client and server in dev mode

```bash
npm run dev
```

run client in dev mode

```bash
npm run client:dev
```

run server in dev mode

```bash
npm run server:dev
```
